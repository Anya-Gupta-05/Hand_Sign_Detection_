# Hand Gesture Detection > 2025-06-13 4:03pm
https://universe.roboflow.com/deep-learning-projects-ljkgq/hand-gesture-detection-pmz9s

Provided by a Roboflow user
License: CC BY 4.0

